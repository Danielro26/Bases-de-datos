function enviarPeticion(url, datos, resultadoId) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById(resultadoId).innerHTML = xhr.responseText;
            console.log(xhr.responseText);
        }
    };
    xhr.send(datos);
}

function agregarMunicipio() {
    var form = document.getElementById('agregarMunicipioForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoAgregar');
    form.reset();
}

function editarMunicipio() {
    var form = document.getElementById('editarMunicipioForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoEditar');
    form.reset();
}

function eliminarMunicipio() {
    var form = document.getElementById('eliminarMunicipioForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoEliminar');
    form.reset();
}

function buscarDepartamento() {
    var form = document.getElementById('buscarDepartamentoForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoBuscarDepartamento');
}

function consultarIngresoSuperior() {
    var form = document.getElementById('consultarIngresoSuperiorForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoConsultarIngreso');
}

function consultarPoblacionIgual() {
    var form = document.getElementById('consultarPoblacionIgualForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoConsultarPoblacion');
}

function visualizarCensoDepartamento() {
    var form = document.getElementById('visualizarCensoDepartamentoForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoVisualizarCensoDepartamento');
}

function visualizarCensoNacional() {
    var form = document.getElementById('visualizarCensoNacionalForm');
    var datos = new FormData(form);
    var params = new URLSearchParams(datos).toString();
    enviarPeticion('backend.php', params, 'resultadoVisualizarCensoNacional');
}

document.addEventListener("DOMContentLoaded", function() {
    var selects = document.querySelectorAll("select");
    var departamentos = [
        'Amazonas', 'Antioquia', 'Arauca', 'Atlántico', 'Bolivar', 'Boyacá', 'Caldas', 'Caquetá',
        'Casanare', 'Cauca', 'Cesar', 'Chocó', 'Córdoba', 'Cundinamarca', 'Guainía', 'Guajira',
        'Guaviare', 'Huila', 'Magdalena', 'Meta', 'Nariño', 'Norte de Santander', 'Putumayo',
        'Quindío', 'Risaralda', 'San Andrés y Providencia', 'Santander', 'Sucre', 'Tolima',
        'Valle Del Cauca', 'Vaupés', 'Vichada'
    ];

    selects.forEach(select => {
        departamentos.forEach((departamento, index) => {
            var option = document.createElement("option");
            option.value = index + 1;
            option.text = departamento;
            select.appendChild(option);
        });
    });
});
