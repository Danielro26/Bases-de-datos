-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS censo_municipal;

-- Seleccionar la base de datos
USE censo_municipal;

-- Crear tabla para almacenar la información de los municipios
CREATE TABLE municipios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    poblacion INT NOT NULL,
    hombres INT NOT NULL,
    edad_promedio FLOAT NOT NULL,
    ingreso_promedio FLOAT NOT NULL,
    temperatura_media FLOAT NOT NULL
);

-- Procedimiento almacenado para agregar un municipio
DELIMITER //

CREATE PROCEDURE agregarMunicipio(
    IN p_nombre VARCHAR(100),
    IN p_poblacion INT,
    IN p_hombres INT,
    IN p_edad_promedio FLOAT,
    IN p_ingreso_promedio FLOAT,
    IN p_temperatura_media FLOAT
)
BEGIN
    INSERT INTO municipios(nombre, poblacion, hombres, edad_promedio, ingreso_promedio, temperatura_media)
    VALUES (p_nombre, p_poblacion, p_hombres, p_edad_promedio, p_ingreso_promedio, p_temperatura_media);
END//

DELIMITER ;

-- Procedimiento almacenado para editar la información de un municipio
DELIMITER //

CREATE PROCEDURE editarMunicipio(
    IN p_id INT,
    IN p_nombre VARCHAR(100),
    IN p_poblacion INT,
    IN p_hombres INT,
    IN p_edad_promedio FLOAT,
    IN p_ingreso_promedio FLOAT,
    IN p_temperatura_media FLOAT
)
BEGIN
    UPDATE municipios
    SET nombre = p_nombre,
        poblacion = p_poblacion,
        hombres = p_hombres,
        edad_promedio = p_edad_promedio,
        ingreso_promedio = p_ingreso_promedio,
        temperatura_media = p_temperatura_media
    WHERE id = p_id;
END//

DELIMITER ;

-- Procedimiento almacenado para eliminar un municipio
DELIMITER //

CREATE PROCEDURE eliminarMunicipio(
    IN p_id INT
)
BEGIN
    DELETE FROM municipios WHERE id = p_id;
END//

DELIMITER ;

-- Procedimiento almacenado para buscar un departamento de un municipio
DELIMITER //

CREATE PROCEDURE buscarDepartamento(
    IN p_nombre_municipio VARCHAR(100),
    OUT p_departamento VARCHAR(100)
)
BEGIN
    SELECT nombre INTO p_departamento
    FROM municipios
    WHERE nombre = p_nombre_municipio;
END//

DELIMITER ;

-- Procedimiento almacenado para consultar departamentos con ingreso superior a un valor dado
DELIMITER //

CREATE PROCEDURE consultarIngresoSuperior(
    IN p_valor_ingreso FLOAT
)
BEGIN
    SELECT nombre
    FROM municipios
    WHERE ingreso_promedio > p_valor_ingreso;
END//

DELIMITER ;

-- Procedimiento almacenado para consultar departamentos con población igual a un valor dado
DELIMITER //

CREATE PROCEDURE consultarPoblacionIgual(
    IN p_valor_poblacion INT
)
BEGIN
    SELECT nombre
    FROM municipios
    WHERE poblacion = p_valor_poblacion;
END//

DELIMITER ;

-- Procedimiento almacenado para visualizar el total del censo por departamento
DELIMITER //

CREATE PROCEDURE visualizarCensoDepartamento(
    IN p_nombre_departamento VARCHAR(100)
)
BEGIN
    SELECT *
    FROM municipios
    WHERE nombre = p_nombre_departamento;
END//

DELIMITER ;

-- Procedimiento almacenado para visualizar el total del censo a nivel nacional
DELIMITER //

CREATE PROCEDURE visualizarCensoNacional()
BEGIN
    SELECT *
    FROM municipios;
END//

DELIMITER ;
