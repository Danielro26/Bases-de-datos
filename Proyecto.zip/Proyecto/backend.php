<?php
$servername = "localhost";
$username = "id22148984_daniel";
$password = "Andresesgay*2";
$dbname = "id22148984_departamentos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$accion = $_POST['accion'];

switch ($accion) {
    case "agregarMunicipio":
        agregarMunicipio($conn);
        break;
    case "editarMunicipio":
        editarMunicipio($conn);
        break;
    case "eliminarMunicipio":
        eliminarMunicipio($conn);
        break;
    case "buscarDepartamento":
        buscarDepartamento($conn);
        break;
    case "consultarIngresoSuperior":
        consultarIngresoSuperior($conn);
        break;
    case "consultarPoblacionIgual":
        consultarPoblacionIgual($conn);
        break;
    case "visualizarCensoDepartamento":
        visualizarCensoDepartamento($conn);
        break;
    case "visualizarCensoNacional":
        visualizarCensoNacional($conn);
        break;
    default:
        echo "Acción no válida.";
        break;
}

$conn->close();

function agregarMunicipio($conn) {
    $nombre = $_POST['nombre'];
    $poblacion = $_POST['poblacion'];
    $hombres = $_POST['hombres'];
    $mujeres = $_POST['mujeres'];
    $edadPromedio = $_POST['edadPromedio'];
    $ingresoPromedio = $_POST['ingresoPromedio'];
    $temperaturaMedia = $_POST['temperaturaMedia'];
    $departamento_id = $_POST['departamento_id'];

    $sql = "CALL agregarMunicipio('$nombre', $poblacion, $hombres, $mujeres, $edadPromedio, $ingresoPromedio, $temperaturaMedia, $departamento_id)";
    if ($conn->query($sql) === TRUE) {
        echo "Municipio agregado correctamente.";
    } else {
        echo "Error: " . $conn->error;
    }
}

function editarMunicipio($conn) {
    $nombre = $_POST['nombre'];
    $poblacion = $_POST['poblacion'];
    $hombres = $_POST['hombres'];
    $mujeres = $_POST['mujeres'];
    $edadPromedio = $_POST['edadPromedio'];
    $ingresoPromedio = $_POST['ingresoPromedio'];
    $temperaturaMedia = $_POST['temperaturaMedia'];
    $departamento_id = $_POST['departamento_id'];

    $sql = "CALL editarMunicipio('$nombre', $poblacion, $hombres, $mujeres, $edadPromedio, $ingresoPromedio, $temperaturaMedia, $departamento_id)";
    if ($conn->query($sql) === TRUE) {
        echo "Municipio editado correctamente.";
    } else {
        echo "Error: " . $conn->error;
    }
}

function eliminarMunicipio($conn) {
    $id = $_POST['id'];

    $sql = "CALL eliminarMunicipio('$id')";
    if ($conn->query($sql) === TRUE) {
        echo "Municipio eliminado correctamente.";
    } else {
        echo "Error: " . $conn->error;
    }
}

function buscarDepartamento($conn) {
    $nombreMunicipio = $_POST['nombreMunicipio'];

    $sql = "CALL buscarDepartamento('$nombreMunicipio')";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Departamento: " . $row["nombre"] . "<br>";
        }
    } else {
        echo "0 resultados";
    }
}

function consultarIngresoSuperior($conn) {
    $valorIngreso = $_POST['valorIngreso'];

    $sql = "CALL consultarIngresoSuperior($valorIngreso)";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Departamento: " . $row["nombre"] . ", Ingreso Promedio: " . $row["ingreso_promedio"] . "<br>";
        }
    } else {
        echo "0 resultados";
    }
}

function consultarPoblacionIgual($conn) {
    $valorPoblacion = $_POST['valorPoblacion'];

    $sql = "CALL consultarPoblacionIgual($valorPoblacion)";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Departamento: " . $row["nombre"] . ", Población: " . $row["poblacion_total"] . "<br>";
        }
    } else {
        echo "0 resultados";
    }
}

function visualizarCensoDepartamento($conn) {
    $nombreDepartamento = $_POST['nombreDepartamento'];

    $sql = "CALL visualizarCensoDepartamento('$nombreDepartamento')";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<table> 
                    <thead>
                        <tr>
                            <th> Departamento </th>
                            <th> Poblacion Total </th>
                            <th> Hombres </th>
                            <th> Mujeres </th>
                            <th> Edad Promedio </th>
                            <th> Ingreso Promedio </th>
                            <th> Temperatura Media </thh
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>". $row["nombre"] ."</td>
                            <td>". $row["poblacion_total"] ."</td>
                            <td>". $row["hombres_total"] ."</td>
                            <td>". $row["mujeres_total"] ."</td>
                            <td>". $row["edad_promedio"] ."</td>
                            <td>". $row["ingreso_promedio"] ."</td>
                            <td>". $row["temperatura_media"] ."</td>
                        </tr>
                    </tbody>
                  </table>";
        }
    } else {
        echo "0 resultados";
    }
}

function visualizarCensoNacional($conn) {
    $sql = "CALL visualizarCensoNacional()";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<table> 
                    <thead>
                        <tr>
                            <th> Poblacion Total </th>
                            <th> Hombres </th>
                            <th> Mujeres </th>
                            <th> Edad Promedio </th>
                            <th> Ingreso Promedio </th>
                            <th> Temperatura Media </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>". $row["poblacion_total"] ."</td>
                            <td>". $row["hombres_total"] ."</td>
                            <td>". $row["mujeres_total"] ."</td>
                            <td>". $row["edad_promedio"] ."</td>
                            <td>". $row["ingreso_promedio"] ."</td>
                            <td>". $row["temperatura_media"] ."</td>
                        </tr>
                    </tbody>
                  </table>";
        }
    } else {
        echo "0 resultados";
    }
}
?>